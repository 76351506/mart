// This file is created by egg-ts-helper@1.34.7
// Do not modify this file!!!!!!!!!
/* eslint-disable */

import 'egg';
import ExportGzip = require('../../../app/middleware/gzip');
import ExportOauth = require('../../../app/middleware/oauth');
import ExportSpa = require('../../../app/middleware/spa');

declare module 'egg' {
  interface IMiddleware {
    gzip: typeof ExportGzip;
    oauth: typeof ExportOauth;
    spa: typeof ExportSpa;
  }
}
