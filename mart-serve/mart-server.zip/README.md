## 校园超市 - 后台
## 安装
  定位项目路径，启动服务器
  ```cmd
    cnpm install
    npm run dev
  ```
  浏览器打开：http://localhost:7001/
